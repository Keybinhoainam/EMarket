<template>
    <div class="user">
        <img data-bs-toggle="modal" data-bs-target="#userModal" width="25" height="25"
            src="https://img.icons8.com/ultraviolet/40/gender-neutral-user.png" alt="gender-neutral-user"
            title="gender-neutral-user" />
    </div>
</template>