<template>
    <div class="d-flex align-items-center justify-content-center text-center font-italic">
        <slot></slot>
    </div>
</template>