<template>
  <main>
    <HomeCarousel />
    <HomeAboutUs />
  </main>
</template>

<script setup>
definePageMeta({
  title: 'Home'
})
</script>