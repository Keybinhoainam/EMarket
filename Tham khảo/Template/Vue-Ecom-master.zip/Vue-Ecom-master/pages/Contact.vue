<template>
    <ContactForm />
</template>

<script setup>
definePageMeta({
    title: 'Contact-Us'
})
useHead({
    link: [{ rel: 'canonical', href: 'https://vue-ecom.vercel.app/contact' }],
});
</script>
